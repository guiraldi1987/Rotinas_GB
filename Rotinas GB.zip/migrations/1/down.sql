
DROP TABLE modules;
DROP TABLE users;
